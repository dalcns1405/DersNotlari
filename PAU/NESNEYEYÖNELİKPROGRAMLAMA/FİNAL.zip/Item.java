

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

//import java.util.List;
import java.util.Iterator;


public class Item<E> implements Comparable<Item<E>> {
    
	public double weight;
	public double value;

	public Item(double value, double weight) {

        this.value = value;
        this.weight = weight;  
    }

    public void setValue(double value) {
        this.value = value;
    }

    public void setWeight(double weight) {
    	this.weight = weight;
    }

    public double getValue() {
    	return this.value;
    }

    public double getWeight() {
    	return this.weight;
    }
    
    
    public ArrayList<Item<E>> sort(ArrayList<Item<E>>  itemL){
    
        Collections.sort(itemL);
        return itemL;
    }

    public Comparator<Item<E>> sortByRatio = new Comparator<Item<E>>(){
        
        @Override
        public int compare(Item<E> item1, Item<E> item2){
            return (int)  ( item1.getValue() / item1.getWeight() - item2.getValue() / item2.getWeight());
        }};

    public ArrayList<Item<E>> sortbyRatio(ArrayList<Item<E>>  items){

        ArrayList<Item<E>> itemsClone = new ArrayList<Item<E>>();

		Iterator<Item<E>> iterator = items.iterator();

		while(iterator.hasNext()){
			itemsClone.add( (Item<E>) iterator.next() );
		}

        Collections.sort(itemsClone, sortByRatio);

        return itemsClone;
    }

    

    @Override
    public int compareTo( Item<E> obj) {
        Item<E> item = (Item<E>) obj;
        if( this.getValue() == item.getValue() ){

            if( this.getWeight() == item.getWeight() ){

                return 0;
            }
            else if( this.getWeight() > item.getWeight() ){

                return 1;
            }
            else{

                return -1;
            }

        }
        else if ( this.getValue() > item.getValue() ){

            return 1;
        }
        else {

            return -1;
        }
        
    }

    @Override
    public String toString() {
        return "Item [value=" + value + ", weight=" + weight + "]";
    }



    
} //class Item<E> sonu
